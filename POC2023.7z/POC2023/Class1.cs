﻿using System;

namespace POC2023
{
    public class Class1
    {
    }
}
