﻿using Modelo.Domain.Entities;
using Modelo.Domain.Interfaces;
using Modelo.Service.Validators;
using Microsoft.AspNetCore.Mvc;
using System;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Authorization;

namespace Modelo.Application.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DevolveJurosController : ControllerBase
    {
        BaseEntity objBaseEntity = new User();
        [HttpGet]
        public ActionResult Test() { return Ok("TesteOK"); }

        [HttpGet]
        public ActionResult<double> Juros()
        {
            
            double taxaJuros = objBaseEntity.Taxa;
            return Ok(taxaJuros);
        }


    }
    [Route("api/calculajuros")]
    [ApiController]
    public class CalculaJurosController : ControllerBase
    {
        BaseEntity objBaseEntity = new User();
        [HttpGet]
        public ActionResult Calc() { return Ok("CalcOK"); }

        [HttpGet]
        public ActionResult<double> CalcJuros(double valorInicial, int tempo)
        {
            //Valor Final = Valor Inicial * (1 + juros) ^ Tempo
            double valorFinal = objBaseEntity.CalcJuros;

            return Ok(valorFinal.ToString("F"));
        }
    }

    [Route("api/showmethecode")]
    [ApiController]
    public class ShowMeTheCodeController : ControllerBase
    {
        [HttpGet]
        public ActionResult ShowMe() { return Ok("TesteOK"); }

    }
}