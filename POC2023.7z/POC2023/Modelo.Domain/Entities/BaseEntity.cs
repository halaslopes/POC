﻿using System;
using System.Collections.Generic;
using System.Text;



namespace Modelo.Domain.Entities
{

    public abstract class BaseEntity
    {
        public virtual int Id { get; set; }
        public virtual double Taxa { get; set; }
        public virtual double CalcJuros { get; set; }



    }
}


namespace Modelo.Domain.Entities
{
    public class User : BaseEntity
    {
        public double TaxaJuros { set => Taxa = 0.01; }

        public void CalculaJuros(double valorInicial, int tempo)
        {
            //Valor Final = Valor Inicial * (1 + juros) ^ Tempo
            double jurosAux = Taxa;
            double valor = (valorInicial * (1 + jurosAux));
            CalcJuros = Math.Pow(valor, tempo);
        }

        public int Mes { get; set; }
    }


}
